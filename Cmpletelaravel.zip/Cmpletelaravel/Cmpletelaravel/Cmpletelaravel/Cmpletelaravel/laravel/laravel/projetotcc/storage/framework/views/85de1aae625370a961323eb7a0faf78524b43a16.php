<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fórum</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .post-card {
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            background: white;
        }
        .comentario-card {
            background: #f8f9fa;
            border-radius: 5px;
            padding: 15px;
            margin: 10px 0;
        }
        .admin-badge {
            background: #dc3545;
            color: white;
            padding: 2px 8px;
            border-radius: 3px;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="/">Fórum</a>
            
            <div class="navbar-nav ms-auto">
                <?php if(auth()->guard('forum')->check()): ?>
                    <span class="navbar-text me-3">
                        Olá, <?php echo e(Auth::guard('forum')->user()->nome); ?>

                        <?php if(Auth::guard('forum')->user()->email === 'admin@forum.com'): ?>
                            <span class="admin-badge ms-2">ADMIN</span>
                        <?php endif; ?>
                    </span>
                    
                    <?php if(Auth::guard('forum')->user()->email === 'admin@forum.com'): ?>
                        <a class="nav-link" href="<?php echo e(route('forum.admin.dashboard')); ?>">Dashboard</a>
                    <?php endif; ?>
                    
                    <form method="POST" action="<?php echo e(route('forum.logout')); ?>" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-outline-light btn-sm">Logout</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if(auth()->guard('forum')->check()): ?>
        <div class="card mb-4">
            <div class="card-header">
                <h5>Criar Nova Postagem</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('forum.post.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <input type="text" class="form-control" name="titulo" placeholder="Título" required>
                    </div>
                    <div class="mb-3">
                        <textarea class="form-control" name="conteudo" rows="3" placeholder="Conteúdo" required></textarea>
                    </div>
                    <div class="mb-3">
                        <input type="file" class="form-control" name="imagem" accept="image/*">
                    </div>
                    <button type="submit" class="btn btn-primary">Publicar</button>
                </form>
            </div>
        </div>
        <?php endif; ?>

        <div class="posts-container">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="post-card">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h5><?php echo e($post->titulo); ?></h5>
                    <small class="text-muted"><?php echo e($post->created_at->format('d/m/Y H:i')); ?></small>
                </div>
                
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="text-primary"><?php echo e($post->forum->nome); ?></span>
                    <?php if(Auth::guard('forum')->check() && 
                       (Auth::guard('forum')->id() === $post->forum_id || 
                        Auth::guard('forum')->user()->email === 'admin@forum.com')): ?>
                    <form method="POST" action="<?php echo e(route('forum.post.destroy', $post)); ?>">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" 
                                onclick="return confirm('Tem certeza?')">Excluir</button>
                    </form>
                    <?php endif; ?>
                </div>

                <p><?php echo e($post->conteudo); ?></p>

                <?php if($post->imagem): ?>
                <div class="mb-3">
                    <img src="<?php echo e(asset('storage/' . $post->imagem)); ?>" alt="Imagem do post" 
                         class="img-fluid rounded" style="max-height: 300px;">
                </div>
                <?php endif; ?>

                <hr>

                <div class="comentarios-section">
                    <h6>Comentários (<?php echo e($post->comentarios->count()); ?>)</h6>
                    
                    <?php if(auth()->guard('forum')->check()): ?>
                    <form method="POST" action="<?php echo e(route('forum.comentario.store', $post)); ?>" class="mb-3">
                        <?php echo csrf_field(); ?>
                        <div class="input-group">
                            <input type="text" class="form-control" name="conteudo" placeholder="Adicionar comentário" required>
                            <button type="submit" class="btn btn-outline-primary">Comentar</button>
                        </div>
                    </form>
                    <?php endif; ?>

                    <?php $__currentLoopData = $post->comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="comentario-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <strong><?php echo e($comentario->forum->nome); ?></strong>
                            <small><?php echo e($comentario->created_at->format('H:i - d/m')); ?></small>
                        </div>
                        <p class="mb-1"><?php echo e($comentario->conteudo); ?></p>
                        
                        <?php if(Auth::guard('forum')->check() && 
                           (Auth::guard('forum')->id() === $comentario->forum_id || 
                            Auth::guard('forum')->user()->email === 'admin@forum.com')): ?>
                        <form method="POST" action="<?php echo e(route('forum.comentario.destroy', $comentario)); ?>">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm mt-1" 
                                    onclick="return confirm('Excluir comentário?')">Excluir</button>
                        </form>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-dismiss alerts after 5 seconds
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
    </script>
</body>
</html><?php /**PATH C:\Users\Etec\Desktop\laravel\laravel\projetotcc\resources\views/forum/index.blade.php ENDPATH**/ ?>