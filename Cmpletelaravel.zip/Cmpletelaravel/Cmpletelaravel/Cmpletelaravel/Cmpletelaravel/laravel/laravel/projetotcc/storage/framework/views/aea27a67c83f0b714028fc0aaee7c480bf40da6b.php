<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Fórum</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Admin Dashboard</a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="<?php echo e(route('forum.index')); ?>">Voltar ao Fórum</a>
                <form method="POST" action="<?php echo e(route('forum.logout')); ?>" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-light btn-sm">Logout</button>
                </form>
            </div>
        </div>
    </nav>

    <div class="container-fluid mt-4">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="row">
            <!-- Stats Cards -->
            <div class="col-md-3 mb-4">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <h5>Total Posts</h5>
                        <h2><?php echo e($totalPosts); ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <h5>Total Comentários</h5>
                        <h2><?php echo e($totalComentarios); ?></h2>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Gráfico Postagens -->
            <div class="col-md-6 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5>Postagens por Data</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="postagensChart" width="400" height="200"></canvas>
                    </div>
                </div>
            </div>

            <!-- Gráfico Comentários -->
            <div class="col-md-6 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5>Comentários por Data</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="comentariosChart" width="400" height="200"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Posts Recentes -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Posts Recentes</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Título</th>
                                        <th>Autor</th>
                                        <th>Data</th>
                                        <th>Comentários</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $postsRecentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(Str::limit($post->titulo, 50)); ?></td>
                                        <td><?php echo e($post->forum->nome); ?></td>
                                        <td><?php echo e($post->created_at->format('d/m/Y H:i')); ?></td>
                                        <td><?php echo e($post->comentarios_count ?? $post->comentarios->count()); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Gráfico de Postagens
        const postagensCtx = document.getElementById('postagensChart').getContext('2d');
        new Chart(postagensCtx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($postagensPorData->pluck('data')); ?>,
                datasets: [{
                    label: 'Postagens',
                    data: <?php echo json_encode($postagensPorData->pluck('total')); ?>,
                    borderColor: 'rgb(75, 192, 192)',
                    tension: 0.1
                }]
            }
        });

        // Gráfico de Comentários
        const comentariosCtx = document.getElementById('comentariosChart').getContext('2d');
        new Chart(comentariosCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($comentariosPorData->pluck('data')); ?>,
                datasets: [{
                    label: 'Comentários',
                    data: <?php echo json_encode($comentariosPorData->pluck('total')); ?>,
                    backgroundColor: 'rgb(54, 162, 235)'
                }]
            }
        });

        // Auto-dismiss alerts
        setTimeout(() => {
            document.querySelectorAll('.alert').forEach(alert => {
                alert.style.display = 'none';
            });
        }, 5000);
    </script>
</body>
</html><?php /**PATH C:\Users\Etec\Desktop\laravel\laravel\projetotcc\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>