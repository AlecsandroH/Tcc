<?php

namespace App\Http\Controllers;

class AutismoController extends Controller
{
    public function index()
    {
        return view('leisedireitos');
    }
}