<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redefinir Senha - Fórum</title>

        <!--Link Favicons-->
    <link rel="icon" href="{{asset('favicons/favicon.ico') }}" type="image/x-icon">
    <link rel="icon" href="{{asset('favicons/apple-touch-icon.png')}}" type="image/png">
    <link rel="icon" href="{{asset('favicons/favicon-16x16.png')}}" type="image/png">
    <link rel="icon" href="{{asset('favicons/favicon-32x32.png')}}" type="image/png">
      
    <!--Link css-->
    <link href="{{asset('css/botoes.css')}}" rel="stylesheet">
    <link href="{{asset('css/cssimage.css')}}" rel="stylesheet">
    <link href="{{asset('css/csspadrao.css')}}" rel="stylesheet">    
    <link href="{{ asset('css/login/reset_senha.css') }}" rel="stylesheet">
    <link href="{{asset('css/reset.css')}}" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <header class="div-cabecalho">
    <a href="/" class="logo">
        <span class="logo-icon"><img src="{{asset('imagens/logonome.png')}}" alt="logo" width="50%" height="50%"></span>
    </a>
        
    <ul class="nav-links">
        <li><a href="/">Início</a></li>
        <li><a href="/tutorial">Tutorial</a></li>
        <li><a href="/sobrenos">Sobre Nós</a></li>
        <li><a href="/atividades">Atividades</a></li>
        <li><a href="/convivendocomtea">Convivendo com TEA</a></li>
        <li><a href="/telaoqautismo">O que é o autismo</a></li>
    </ul>
</header>
    <div class="container">
        <div class="auth-card">
            <h2 class="text-center mb-4">Redefinir Senha</h2>
            <p class="text-muted text-center mb-4">Digite seu email e sua nova senha</p>

            @if(session('success'))
                <div class="alert alert-success alert-dismissible fade show">
                    {{ session('success') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif

            @if($errors->any())
                <div class="alert alert-danger">
                    @foreach($errors->all() as $error)
                        <p class="mb-0">{{ $error }}</p>
                    @endforeach
                </div>
            @endif

            <form method="POST" action="{{ route('forum.password.update') }}" id="passwordForm">
                @csrf
                
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control @error('email') is-invalid @enderror" 
                           id="email" name="email" value="{{ old('email') }}" required autofocus>
                    @error('email')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="mb-3 password-container">
                    <label for="password" class="form-label">Nova Senha</label>
                    <input type="password" class="form-control @error('password') is-invalid @enderror" 
                           id="password" name="password" required>
                    <button type="button" class="password-toggle" id="togglePassword">Mostrar 🔓</button>
                    @error('password')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                    <div class="password-requirements">
                        A senha deve ter pelo menos 6 caracteres
                    </div>
                </div>

                <div class="mb-3 password-container">
                    <label for="password_confirmation" class="form-label">Confirmar Nova Senha</label>
                    <input type="password" class="form-control" 
                           id="password_confirmation" name="password_confirmation" required>
                    <button type="button" class="password-toggle" id="togglePasswordConfirmation">Mostrar 🔓</button>
                </div>

                <button type="submit" class="btn_redefinir" id="submitBtn">Redefinir Senha</button>

                <div class="text-center">
                    <a href="{{ route('forum.login') }}" class="text-decoration-none">← Voltar para o login</a>
                </div>
            </form>
        </div>
    </div>

    <footer class="div-final">
    <ul class="nav-links">
        <li><a href="/">Início</a></li>
        <li><a href="/tutorial">Tutorial</a></li>
        <li><a href="/sobrenos">Sobre Nós</a></li>
        <li><a href="/atividades">Atividades</a></li>
        <li><a href="/convivendocomtea">Convivendo com TEA</a></li>
        <li><a href="/telaoqautismo">O que é o autismo</a></li>
    </ul>
    <span class="logo-icon"><img src="{{asset('favicons/apple-touch-icon.png')}}" alt="logo" width="50%" height="50%"></span>
</footer>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);

        // Mostrar/ocultar senha
        document.addEventListener('DOMContentLoaded', function() {
            // Função para alternar visibilidade
            function togglePasswordVisibility(inputId, toggleButton) {
                const input = document.getElementById(inputId);
                if (input.type === 'password') {
                    input.type = 'text';
                    toggleButton.textContent = 'Ocultar 🔒';
                    toggleButton.setAttribute('aria-label', 'Ocultar 🔒');
                } else {
                    input.type = 'password';
                    toggleButton.textContent = 'Mostrar 🔓';
                    toggleButton.setAttribute('aria-label', 'Mostrar 🔓');
                }
            }

            // Configurar botões de mostrar/ocultar
            const togglePassword = document.getElementById('togglePassword');
            const togglePasswordConfirmation = document.getElementById('togglePasswordConfirmation');

            if (togglePassword) {
                togglePassword.addEventListener('click', function() {
                    togglePasswordVisibility('password', togglePassword);
                });
            }

            if (togglePasswordConfirmation) {
                togglePasswordConfirmation.addEventListener('click', function() {
                    togglePasswordVisibility('password_confirmation', togglePasswordConfirmation);
                });
            }

            // Estado de carregamento do formulário
            const form = document.getElementById('passwordForm');
            const submitBtn = document.getElementById('submitBtn');

            if (form && submitBtn) {
                form.addEventListener('submit', function() {
                    submitBtn.classList.add('btn-loading');
                    submitBtn.disabled = true;
                });
            }

            // Validação em tempo real da confirmação de senha
            const passwordInput = document.getElementById('password');
            const confirmPasswordInput = document.getElementById('password_confirmation');

            if (passwordInput && confirmPasswordInput) {
                confirmPasswordInput.addEventListener('input', function() {
                    if (passwordInput.value !== confirmPasswordInput.value) {
                        confirmPasswordInput.classList.add('is-invalid');
                    } else {
                        confirmPasswordInput.classList.remove('is-invalid');
                    }
                });
            }
        });
    </script>
</body>
</html>